package com.gyq.fengshui;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class WebActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.web_layout);
        WebView wv = (WebView)findViewById(R.id.mainWebView);//通过findViewById寻找元素
        String url = getIntent().getStringExtra("url");
      //  Toast.makeText(WebActivity.this,url,Toast.LENGTH_SHORT).show();
        wv = (WebView) findViewById(R.id.mainWebView);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        wv.getSettings().setSupportMultipleWindows(true);
        wv.getSettings().setBuiltInZoomControls(true);
        wv.getSettings().setDefaultTextEncodingName("gbk");
        wv.setWebViewClient(new WebViewClient());
        wv.setWebChromeClient(new WebChromeClient());
        wv.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent)
            {
              //  Log.d("browser","motionEvent:"+motionEvent.toString());
                return false;
            }
        });
        wv.loadUrl(url);
    }
}
